#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys

import webalbumgenerator.example

if __name__ == "__main__":
	an_example = webalbumgenerator.example.Example()
	sys.exit(an_example.main())
